﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TUP_PI_EF_DGR.Negocio;
using TUP_PI_EF_DGR.Servicios;

//CURSO 1w3  – LEGAJO 412010 – APELLIDO PIOTTI PEREYRA – NOMBRE CIBELS ANTONELLA

//Cadena de Conexión: "Data Source=172.16.10.196;Initial Catalog=DGR;User ID=alumno1w1;Password=alumno1w1"

namespace TUP_PI_EF_DGR
{
    public partial class FrmInmuebles : Form
    {
        private Servicio _servicio = new Servicio();
        private int codigo;
        public FrmInmuebles()
        {
            InitializeComponent();
        }

        private void FrmInmuebles_Load(object sender, EventArgs e)
        {
            CargarCombo();
            CargarInmuebles();
        }

        private void CargarInmuebles()
        {
           List<Inmueble> inmuebles = _servicio.CargarInmuebles();
            lstInmuebles.DataSource = inmuebles;

        }

        private void CargarCombo()
        {
            DataTable dt = _servicio.CargarCategorias();
            cboCategoria.DataSource = dt;
            cboCategoria.ValueMember = dt.Columns[0].ColumnName;
            cboCategoria.DisplayMember = dt.Columns[1].ColumnName;
            cboCategoria.SelectedIndex = -1;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
           
                if (lstInmuebles.SelectedItem is Inmueble selectedInmueble)
                {
                    codigo = selectedInmueble.IdInmueble;
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione un inmueble de la lista.");
                }

            Inmueble inmuebleEditar = CargarInmueble();
            txtTitular.Text = inmuebleEditar.Titular;
            txtNomenclatura.Text = inmuebleEditar.Nomenclatura.ToString();
            rbtRural.Checked = inmuebleEditar.Tipo == 1;
            rbtUrbano.Checked = inmuebleEditar.Tipo == 2;
            cboCategoria.SelectedValue = inmuebleEditar.Categoria.IdCategoria;
            txtTerreno.Text = inmuebleEditar.SupTerreno.ToString();
            txtEdificada.Text = inmuebleEditar.SupEdificada.ToString();
            txtValuacion.Text = inmuebleEditar.Valuacion.ToString();
            btnGrabar.Enabled = true;


        }
        public bool Validar()
        {
            if (string.IsNullOrEmpty(txtTitular.Text))
            {
                MessageBox.Show("Debe ingresar el titular del inmueble.");
                txtTitular.Focus();
                return false;
            }
            if (!rbtRural.Checked && !rbtUrbano.Checked)
            {
                MessageBox.Show("Debe seleccionar el tipo de inmueble.");
                rbtRural.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtNomenclatura.Text) || !int.TryParse(txtNomenclatura.Text, out _))
            {
                MessageBox.Show("Debe ingresar una nomenclatura válida (número entero).");
                txtNomenclatura.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtTerreno.Text) || !double.TryParse(txtTerreno.Text, out _))
            {
                MessageBox.Show("Debe ingresar una superficie del terreno válida (número decimal).");
                txtTerreno.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtEdificada.Text) || !double.TryParse(txtEdificada.Text, out _))
            {
                MessageBox.Show("Debe ingresar una superficie edificada válida (número decimal).");
                txtEdificada.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtValuacion.Text) || !double.TryParse(txtValuacion.Text, out _))
            {
                MessageBox.Show("Debe ingresar una valuación válida (número decimal).");
                txtValuacion.Focus();
                return false;
            }
            if (cboCategoria.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar una categoría.");
                cboCategoria.Focus();
                return false;
            }
            if (cboCategoria.SelectedIndex == 1)
            {
                txtEdificada.Text = "";
                txtEdificada.Enabled = false;
            }
            return true;
        }


        private Inmueble CargarInmueble()
        {
            Inmueble inmueble = _servicio.CargarInmueble(codigo);
            return inmueble;
        }


        private void btnGrabar_Click(object sender, EventArgs e)
        {
            if (Validar())
            {
                Inmueble inmueble = CrearInmueble();
                _servicio.ActualizarInmueble(inmueble);
                CargarInmuebles();
                Limpiar();
            }
            
        }

        private void Limpiar()
        {
            btnGrabar.Enabled = false;
            txtEdificada.Text = "";
            txtNomenclatura.Text = string.Empty;
            txtTerreno.Text = string.Empty;
            txtTitular.Text = string.Empty;
            rbtRural.Checked = false;
            rbtUrbano.Checked = false;
            cboCategoria.SelectedIndex = -1;
        txtValuacion.Text = string.Empty;
        }

        private Inmueble CrearInmueble()
        {
            int tipo = 0;
            if (rbtRural.Checked)
            {
                tipo = 2;
            }
            else if (rbtUrbano.Checked)
            {
                tipo = 1;
            }

            Inmueble inmu = new Inmueble
            {
                IdInmueble = codigo,
                Titular = txtTitular.Text,
                Nomenclatura = Convert.ToInt32(txtNomenclatura.Text),
                Tipo = tipo,
                Categoria = new Categoria
                {
                    IdCategoria = Convert.ToInt32(cboCategoria.SelectedValue),
                    nCategoria = cboCategoria.Text
                },
                SupTerreno = Convert.ToDouble(txtTerreno.Text),
                SupEdificada = Convert.ToDouble(txtEdificada.Text),
                Valuacion = Convert.ToDouble(txtValuacion.Text)
            };
            return inmu;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Esta seguro de que desea salir?", "SALIR", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.Close();
            }
                
        }
        private void txtNomenclatura_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void txtValuacion_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtNomenclatura_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
