﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUP_PI_EF_DGR.AccesoDatos;
using TUP_PI_EF_DGR.Negocio;

namespace TUP_PI_EF_DGR.Servicios
{
    public class Servicio
    {
        private CategoriaDao _categoriaDao = new CategoriaDao();
        private InmuebleDao _inmuebleDao = new InmuebleDao();

        public DataTable CargarCategorias()
        {
            return _categoriaDao.CargarCategorias();
        }

        public List<Inmueble> CargarInmuebles()
        {
            return _inmuebleDao.CargarInmuebles();
        }

        internal void ActualizarInmueble(Inmueble inmueble)
        {
            _inmuebleDao.ActualizarInmu(inmueble);
        }

        internal Inmueble CargarInmueble(int codigo)
        {
            return _inmuebleDao.CargarInmueble(codigo);
        }
    }
}
