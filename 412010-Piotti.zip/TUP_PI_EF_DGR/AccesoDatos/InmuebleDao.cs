﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TUP_PI_EF_DGR.Negocio;

namespace TUP_PI_EF_DGR.AccesoDatos
{
    public class InmuebleDao
    {
        private AccesoDatos _acceso = new AccesoDatos();

        public List<Inmueble> CargarInmuebles()
        {
            DataTable dt = _acceso.ConsultarTabla2(" id_inmueble, titular, nomenclatura, id_categoria, n_categoria, valuacion from Inmuebles i join categorias c on i.categoria = c.id_categoria ");
            List<Inmueble> inmuebles = new List<Inmueble>();
            foreach (DataRow dr in dt.Rows)
            {
                Categoria cat = new Categoria();
                cat.IdCategoria = Convert.ToInt32(dr["id_categoria"]);
                cat.nCategoria = dr["n_categoria"].ToString();

                Inmueble inmueble = new Inmueble();
                inmueble.IdInmueble = Convert.ToInt32(dr["id_inmueble"]);
                inmueble.Titular = dr["titular"].ToString();
                inmueble.Nomenclatura = Convert.ToInt32(dr["nomenclatura"]);
                inmueble.Categoria = cat; //aca tengo que mostrar rural
                inmueble.Valuacion = Convert.ToDouble(dr["valuacion"]);
                inmuebles.Add(inmueble);
            }

            return inmuebles;
        }

        internal void ActualizarInmu(Inmueble inmueble)
        {
            string consulta = "update Inmuebles set titular = '" + inmueble.Titular + "', nomenclatura = " + inmueble.Nomenclatura + ", tipo = " + inmueble.Tipo+ ", categoria = " + inmueble.Categoria.IdCategoria + ", sup_terreno= " + inmueble.SupTerreno + ", sup_edificada= " + inmueble.SupEdificada + ", valuacion= " + inmueble.Valuacion + " where id_inmueble = " + inmueble.IdInmueble;
            int filasAfectadas = _acceso.ActualizarBD(consulta);
            if (filasAfectadas >0)
            {
                MessageBox.Show("Inmueble Actualizado");
            } else
            {
                MessageBox.Show("Error al actualizar el inmueble");
            }
        }

        internal Inmueble CargarInmueble(int codigo)
        {
            string query = $" id_inmueble, titular, nomenclatura, tipo, id_categoria, n_categoria, valuacion, sup_terreno, sup_edificada from Inmuebles i join categorias c on i.categoria = c.id_categoria where id_inmueble = {codigo}";
            DataTable dt = _acceso.ConsultarTabla2(query);
            if (dt.Rows.Count>0)
            {
                Inmueble inmueble = new Inmueble
                {
                    IdInmueble = codigo,
                    Titular = dt.Rows[0]["titular"].ToString(),
                    Nomenclatura = Convert.ToInt32(dt.Rows[0]["nomenclatura"]),
                    Tipo = Convert.ToInt32(dt.Rows[0]["tipo"]),
                    Categoria = new Categoria
                    {
                        IdCategoria = Convert.ToInt32(dt.Rows[0]["id_categoria"]),
                        nCategoria = dt.Rows[0]["n_categoria"].ToString()
                    },
                    Valuacion = Convert.ToDouble(dt.Rows[0]["valuacion"]),
                    SupTerreno = Convert.ToDouble(dt.Rows[0]["sup_terreno"]),
                    SupEdificada = Convert.ToDouble(dt.Rows[0]["sup_edificada"])
                };
                return inmueble;
            }
            return null;
        }
    }
}
