﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TUP_PI_EF_DGR.AccesoDatos
{
    public class CategoriaDao
    {
        private AccesoDatos _acceso = new AccesoDatos();

        public DataTable CargarCategorias()
        {
            DataTable dt = _acceso.ConsultarTabla("Categorias");
            return dt;
        }
    }
}
